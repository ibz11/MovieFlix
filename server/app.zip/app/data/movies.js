const movies =[
    {
        id:1,
        title:"Han Solo: A Starwars Story",
        image:"https://orangemagazine.ph/wp-content/uploads/2018/05/Solo-HanSolo-702x1024.jpg",
        year:"2018",
        link:"https://www.youtube.com/embed/jPEYpryMp2s?si=ZKVygDAvawxlf8hO"
    },
    {
        id:2,
        title:"Stranger things",
        image:"https://m.media-amazon.com/images/I/91miBpFYN5L.jpg",
        year:"2018",
        link:"https://www.youtube.com/embed/sBEvEcpnG7k?si=30WsaBodGeeL0iok"
    }
    ,
    {
        id:3,
        title:"Rebel Moon Part One:Child of Fire",
        image:"https://m.media-amazon.com/images/M/MV5BYzlhNzBmYjUtNjRmZC00MDg3LWE4NDMtZDNjODUwNTljMzhlXkEyXkFqcGdeQXVyODk4OTc3MTY@._V1_FMjpg_UX1000_.jpg",
        year:"2023",
        link:"https://www.youtube.com/embed/_rHLOXbFZtI?si=_95MK_h7kPQl2Sff"
    }



]

module.exports=movies